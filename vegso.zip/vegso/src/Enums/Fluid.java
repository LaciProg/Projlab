package Enums;

public enum Fluid {
    DRY, STICKY, SLIPPERY
}
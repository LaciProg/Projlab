package Drawing;

import javax.swing.*;
import java.awt.*;

/**
 * Drawable class
 */
public abstract class Drawable {
    protected int x;
    protected int y;

    /**
     * Get x
     * @return x
     */
    public int getX() {
        return x;
    }

    /**
     * Get y
     * @return y
     */
    public int getY() {
        return y;
    }

    /**
     * Draw method
     * @param panel
     * @param g
     */
    public void Draw(JPanel panel, Graphics2D g) {
    }
}

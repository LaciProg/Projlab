package Fields.ActiveFields;

import Controll.Szkeleton;
import Fields.Pipe;

/**
 * Class for Cistern
 * */
public class Cistern extends ActiveFields{

    /**
     * Water stored in the cistern. Default value is 0.
     */
    private int waterStored;

    /**
     * Constructor for the cistern.
     */
    public Cistern() {
        Szkeleton.printTabs();
        System.out.println("new Cistern()");
        this.waterStored = 0;
    }

    /**
     * Method for the game controlled events.
     * Gets the water from the pipes and stores it.
     * Creates a new pipe
     */
    @Override
    public void step() {
        Szkeleton.printTabs();
        System.out.println(Szkeleton.objectNames.get(this)+ ".step()");
        Szkeleton.tabs++;
        for(Pipe pipe : getPipes()){
            waterStored += pipe.getWater();
        }
        Szkeleton.tabs--;
    }

    /**
     * Method for creating a new pump.
     * @param b True if the player get a new pump.
     * @return The new pump.
     * */
    @Override
    public Pump createNewPump(boolean b) {
        Szkeleton.printTabs();
        System.out.println(Szkeleton.objectNames.get(this)+ ".createNewPump()");
        Pump newPump = new Pump(100);
        Szkeleton.objectNames.put(newPump, "newPump");
        return newPump;
    }

    /**
     * Method for getting the water from the field.
     * Prints the amount of water taken.
     * @return The amount of water in the field.
     */
    @Override
    public int getWater() {
        Szkeleton.printTabs();
        System.out.println(Szkeleton.objectNames.get(this)+ ".getWater()");
        int w = super.getWaterNoChange();
        Szkeleton.printTabs();
        System.out.println(w);
        return w;
    }

    /**
     * Method for picking up a (new) pipe from the field.
     * @return The new pipe.
     */
    @Override
    public Pipe pickUpPipe() {
        Szkeleton.printTabs();
        Szkeleton.tabs++;
        System.out.println(Szkeleton.objectNames.get(this)+ ".pickUpPipe()");
        Pipe newPipe = new Pipe(65);
        Szkeleton.tabs--;
        return newPipe;
    }
}
